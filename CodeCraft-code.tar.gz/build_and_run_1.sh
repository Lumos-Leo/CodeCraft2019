#!/bin/bash
sh build.sh
cd bin
./CodeCraft-2019 ../config1/car.txt ../config1/road.txt ../config1/cross.txt ../config1/presetAnswer.txt ../config1/answer.txt