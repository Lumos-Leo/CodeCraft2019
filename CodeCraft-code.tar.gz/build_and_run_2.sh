#!/bin/bash
sh build.sh
cd bin
./CodeCraft-2019 ../config2/car.txt ../config2/road.txt ../config2/cross.txt ../config2/presetAnswer.txt ../config2/answer.txt